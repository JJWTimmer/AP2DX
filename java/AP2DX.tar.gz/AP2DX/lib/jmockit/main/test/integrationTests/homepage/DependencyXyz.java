/*
 * Copyright (c) 2006-2011 Rogério Liesenfeld
 * This file is subject to the terms of the MIT license (see LICENSE.txt).
 */
package integrationTests.homepage;

public final class DependencyXyz
{
   public int doSomething(String s)
   {
      return -1;
   }
}
