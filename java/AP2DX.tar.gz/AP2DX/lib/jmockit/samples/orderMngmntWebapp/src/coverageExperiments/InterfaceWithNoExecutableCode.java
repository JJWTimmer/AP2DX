package coverageExperiments;

public interface InterfaceWithNoExecutableCode
{
   void doSomething();
}

