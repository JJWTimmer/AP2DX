package coverageExperiments;

public interface UnusedInterface
{
   void doSomething();
}