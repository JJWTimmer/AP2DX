package unitils.wiki;

public class TextService
{
   public String getText()
   {
      return "the text";
   }
}
