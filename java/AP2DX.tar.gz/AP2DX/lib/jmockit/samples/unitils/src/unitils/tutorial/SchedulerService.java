package unitils.tutorial;

import java.util.*;

public interface SchedulerService
{
   List<Message> getScheduledAlerts(Object arg0, int arg1, boolean arg2);
}
