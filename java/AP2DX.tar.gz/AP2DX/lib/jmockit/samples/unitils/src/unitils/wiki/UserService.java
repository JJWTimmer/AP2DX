package unitils.wiki;

public class UserService
{
   public User getUser()
   {
      return null;
   }
}
