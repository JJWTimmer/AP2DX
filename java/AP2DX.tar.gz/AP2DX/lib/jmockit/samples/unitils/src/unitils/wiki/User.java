package unitils.wiki;

public class User
{
   public String getName()
   {
      return "";
   }
}
