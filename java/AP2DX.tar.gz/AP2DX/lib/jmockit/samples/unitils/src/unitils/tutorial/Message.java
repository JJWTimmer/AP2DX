package unitils.tutorial;

public class Message
{
}
