package unitils.tutorial;

public final class Alert extends Message
{
}
