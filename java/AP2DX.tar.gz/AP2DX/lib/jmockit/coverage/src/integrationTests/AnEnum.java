package integrationTests;

public enum AnEnum
{
   OneValue,
   AnotherValue
}