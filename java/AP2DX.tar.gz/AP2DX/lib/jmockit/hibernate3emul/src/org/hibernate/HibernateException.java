package org.hibernate;

public class HibernateException extends RuntimeException
{
}
