package org.hibernate;

public interface StatelessSession
{
}
