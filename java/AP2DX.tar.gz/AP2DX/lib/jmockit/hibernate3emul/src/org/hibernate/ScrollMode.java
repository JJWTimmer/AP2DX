package org.hibernate;

public final class ScrollMode
{
}
