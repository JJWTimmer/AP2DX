package org.hibernate;

public final class EntityMode
{
}
