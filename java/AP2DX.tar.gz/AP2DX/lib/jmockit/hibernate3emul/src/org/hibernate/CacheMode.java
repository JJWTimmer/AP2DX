package org.hibernate;

public final class CacheMode
{
   public static final CacheMode NORMAL = new CacheMode();

   private CacheMode() {}
}
