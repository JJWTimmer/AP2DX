package org.hibernate;

public interface Filter
{
}
