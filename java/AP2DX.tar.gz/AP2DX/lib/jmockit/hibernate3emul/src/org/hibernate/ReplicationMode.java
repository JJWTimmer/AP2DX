package org.hibernate;

public final class ReplicationMode
{
}
