package org.hibernate;

public final class NonUniqueResultException extends RuntimeException
{
   public NonUniqueResultException(int resultCount) {}
}
