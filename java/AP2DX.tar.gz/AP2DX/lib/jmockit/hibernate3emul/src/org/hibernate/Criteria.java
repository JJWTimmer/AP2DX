package org.hibernate;

public interface Criteria
{
}
