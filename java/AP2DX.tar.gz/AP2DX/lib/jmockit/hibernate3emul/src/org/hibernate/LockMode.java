package org.hibernate;

public final class LockMode
{
}
