package org.hibernate;

public final class FlushMode
{
   public static final FlushMode AUTO = new FlushMode();

   private FlushMode() {}
}
