package org.hibernate;

public interface Interceptor
{
}
