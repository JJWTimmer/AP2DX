package org.hibernate;

public interface SQLQuery
{
}
