package org.hibernate;

public interface Transaction
{
   void rollback();
}
