package AP2DX.coordinator;

import AP2DX.test.AP2DXBaseTestCase;

public class Tryout2
{
    public static void main(String[] args)
    {
        AP2DXBaseTestCase b = new AP2DXBaseTestCase();
//        b.testietest();
    }
}
