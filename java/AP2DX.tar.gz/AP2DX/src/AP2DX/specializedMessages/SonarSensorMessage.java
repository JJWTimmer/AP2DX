package AP2DX.specializedMessages;

import java.util.HashMap;

import AP2DX.*;

//import org.json.simple.JSONObject;
import org.json.JSONArray;
import org.json.JSONObject;
import org.json.JSONException;

/**
* Specialized message for sensor data
*
* An example of a USAR sonar message:
* SEN {Time 395.7716} {Type Sonar} {Name F1 Range 4.5798} {Name F2 Range 2.1461} {Name F3 Range 1.7450} {Name F4 Range 1.5893} {Name F5 Range 0.6239} {Name F6 Range 0.7805} {Name F7 Range 1.2004} {Name F8 Range 2.0657}
*
* Sonars' positions are: (USER sim manual)
* { X(mm), Y(mm), Theta(deg) } = 
* { 155, -130, -90}
* { 155, -115, -50}
* { 190, -805, -30}
* { 210, -25, -10}
* { 210, 25, 10}
* { 190, 80, 30}
* { 155, 115, 50}
* { 115, 130, 90}
*
* @author Maarten Inja
*/
public class SonarSensorMessage extends SpecializedMessage 
{
    private double[] rangeArray;
    private double time;


    /** Creates a specialized message from a standard AP2DXMessage.
    * This constructor could be used to clone an AP2DXMessage. */
    public SonarSensorMessage(AP2DXMessage message)
    {
        super(message);
    }

	public SonarSensorMessage(Module sourceId, Module destinationId)
	{
		super(Message.MessageType.AP2DX_SENSOR_SONAR, sourceId, destinationId);
	}

    public SonarSensorMessage(AP2DXMessage message, Module sourceId, Module destinationId)
    {
        super(message, sourceId, destinationId);
        if (values == null)
            values = new HashMap();
        setTime(time);
        setRangeArray(rangeArray);
    }

    /** Apparently causes Logic to throw nullpointer exceptions.... :S */
    public SpecializedMessage forward(Module sourceId, Module destinationId)
    {
        SonarSensorMessage message = new SonarSensorMessage( (AP2DXMessage) clone());
        message.parseMessage();
        message.setSourceModuleId(sourceId);
        message.setDestinationModuleId(sourceId);  
        message.compileMessage();
        return message;
    } 
    
    /** 
     * Creates a (new) string in messageString from whatever is in the values map. 
     */
    @Override
     public String compileMessage()
     {   
    	if (messageString != null)
    		specializedParseMessage();
    	
         try
         {
             if (values == null)
                 values = new HashMap();
             values.put("destinationModuleId", destinationModuleId.toString());
             values.put("sourceModuleId", sourceModuleId.toString());
             values.put("type", type.typeString.toString());
             messageString = (new JSONObject(values)).toString();
         }
         catch (Exception e)
         {
             System.out.println("Error in AP2DX.SpecializedMessages.OdometrySensormessage.compileMessage: " + e.getMessage());
             e.printStackTrace();
         }
         return messageString;
     }

    public void specializedParseMessage()
    {
        //time = Double.parseDouble(values.get("time").toString());

        //System.out.printf("In specializedParseMessage of Sonar with string %s\n", messageString);
		try 
        { 
            // this is, if I'm correct, also in the values map, which 
            // can normally be used to extract the variables, were it not
            // for arrays ...
            JSONObject jsonObject = new JSONObject(messageString);
            JSONArray jsonArray = jsonObject.getJSONArray("rangeArray");
            rangeArray = new double[jsonArray.length()];
            for (int i = 0; i < jsonArray.length(); i ++)
                rangeArray[i] = jsonArray.getDouble(i);
            time = jsonObject.getDouble("time");
            setRangeArray(rangeArray);
            setTime(time);
            // For testing purposes:
        }
        catch (Exception e)
        {
            System.out.println("Error in AP2DX.specializedMessages.SonarSensorMessage.specializedParseMessage()... things went south!");
            e.printStackTrace();
        }
        //setRangeArray(rangeArray);
        //setTime(time);
        //System.out.printf("Rangearray now is %s, with first %f\n", this.rangeArray.toString(), this.rangeArray[0]);
    }

    // setters and getters {{{

    public void setRangeArray(double[] value)
    {
        rangeArray = value;
        values.put("rangeArray", value);
    }

    public void setTime(double value)
    {
        time = value;
        values.put("time", value);
    }

    /** The array of Sonar data.*/
    public double[] getRangeArray()
    {
        return rangeArray;
    }

    public double getTime()
    {
        return time;
    }

    // }}}
}
