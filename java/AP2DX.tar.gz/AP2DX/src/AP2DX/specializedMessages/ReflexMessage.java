package AP2DX.specializedMessages;

public class ReflexMessage {

}
